CREATE TABLE IF NOT EXISTS accounts (
    id int NOT NULL AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(12) NOT NULL DEFAULT '',
    ownerkey VARCHAR(54)  NOT NULL DEFAULT '',
    activekey VARCHAR(54)  NOT NULL DEFAULT '',
    creator VARCHAR(12) NOT NULL DEFAULT '',
    created_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) engine=innodb default charset=utf8;


CREATE TABLE IF NOT EXISTS transactions (
    id int NOT NULL AUTO_INCREMENT PRIMARY KEY,
    hash_ VARCHAR(64) NOT NULL DEFAULT '',
    expiration VARCHAR(24) NOT NULL DEFAULT '',
    block_num int NOT NULL,
    cpu int NOT NULL,
    net int NOT NULL,
    contract_ VARCHAR(20) NOT NULL DEFAULT '',
    action_ VARCHAR(20) NOT NULL DEFAULT '',
    actor VARCHAR(20) NOT NULL DEFAULT '',
    data_ JSON,
    created_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) engine=innodb default charset=utf8;


CREATE TABLE IF NOT EXISTS assets (
    username VARCHAR(12) NOT NULL DEFAULT '',
    contract_ VARCHAR(20)  NOT NULL DEFAULT '',
    quantity DECIMAL(18,4) NOT NULL,
    symbol VARCHAR(20) NOT NULL DEFAULT '',
    created_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) engine=innodb default charset=utf8;


CREATE TABLE IF NOT EXISTS tokens (
    contract_ VARCHAR(20)  NOT NULL DEFAULT '',
    symbol VARCHAR(12) NOT NULL DEFAULT '',
    maxsupply DECIMAL(18,4) NOT NULL,
    supply DECIMAL(18,4),
    precision_ DECIMAL(18,4),
    logo VARCHAR(256)  NOT NULL DEFAULT '',
    price DECIMAL(18,4),
    site_ VARCHAR(56),
    created_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) engine=innodb default charset=utf8;


ALTER TABLE transactions ADD INDEX index_hash (hash_);
ALTER TABLE transactions ADD INDEX index_block_num (block_num);
ALTER TABLE transactions ADD INDEX index_contract (contract_);
ALTER TABLE transactions ADD INDEX index_actor (actor);

ALTER TABLE assets ADD INDEX index_username_contract (username, contract_);
