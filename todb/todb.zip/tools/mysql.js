var mysql = require('promise-mysql');

// 35.73.165.22
// 127.0.0.1
MysqlPool = mysql.createPool({
    host: '35.73.165.22',
    user: 'exone',
    password: 'Roxe.6G!',
    database: 'roxe',
    connectionLimit: 30
});

exports.MysqlPool = MysqlPool;
