const todb = require('./lib/todb')
// const test = require('./lib/test')
const rpc = require('./tools/rpc')

console.log('0c2758036c8be566160f60994da63a8fd82471925b435aeb160157c254326676'.length)
// rpc.getCurrencyBalance('roxe.ro', '11hojv2yjpdh', 'HKD')
// rpc.getCurrencyBalance('roxe.ro', '11hojv2yjpdh', 'GBP')
// rpc.getCurrencyBalance('roxe.ro', '11hojv2yjpdh', 'USD')

rpc.getCurrencyBalance('roxe.ro', 'w1ijwddrqd3o', 'BTC')
// rpc.getBlockByID('57338863')
// rpc.getBlockByID('57338863')
// w1ijwddrqd3o | roxe.ro    |         -1.9911 | BTC 

// test.test()
// todb.getBlockNumByRpc()