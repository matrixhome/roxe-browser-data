const rpcurl = 'http://127.0.0.1:8888/v1/chain'
// const rpcurl = 'http://47.75.253.127:8888/v1/chain'
// const rpcurl = 'http://api.main.alohaeos.com/v1/chain'


module.exports = {
    rpcurl: rpcurl
  }