// const { Pool, Client } = require('pg')
// const { pgsqlOptions } = require('../config')


// const pgsqlPool = new Pool({
//   user: pgsqlOptions.user,
//   host: pgsqlOptions.host,
//   database: pgsqlOptions.database,
//   password: pgsqlOptions.password,
//   port: pgsqlOptions.port,
//   max: 77,
//   idleTimeoutMillis: 30000,
//   connectionTimeoutMillis: 2000,
// })


// module.exports = {
//   pgsqlPool: pgsqlPool
// }