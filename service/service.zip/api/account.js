const rpc = require('../tools/rpc')
const pool = require('../tools/mysql').MysqlPool

/**
 * @api {get} /getAccountDetail
 * @apiGroup account
 * @apiVersion 1.0.0
 * @apiDescription 获取账号详细信息
 * @apiParam {String} account
 * 
 */
async function getAccountDetail(ctx) {
    let accountname = ctx.request.query.account
    let account = {
        detail: '',
        tokens: '',
        by: ''
    }
    account.detail = await rpc.getAccountDetail(accountname)
    account.tokens = await pool.then(function(conn) {
        return conn.query('select * from assets where username = ?', [accountname]);
      })
    account.by = await pool.then(function(conn) {
      return conn.query('select creator from accounts where username = ?', [accountname]);
    })
    ctx.body = account
}

/**
 * @api {get} /getNodeList
 * @apiGroup account
 * @apiVersion 1.0.0
 * @apiDescription 获取超级节点
 */
async function getNodeList(ctx) {
    let nodes = await rpc.getTableLow('roxe', 'roxe', 'producers')
    ctx.body = nodes
}

/**
 * @api {get} /getAccountCount
 * @apiGroup account
 * @apiVersion 1.0.0
 * @apiDescription 获取account 总数
 */
 async function getAccountCount(ctx) {
    let num = await pool.then(function(conn) {
      return conn.query('select id from accounts order by id desc limit 1');
    })
    ctx.body = num
  }

/**
 * @api {get} /getTokens
 * @apiGroup account
 * @apiVersion 1.0.0
 * @apiDescription 获取token 列表
 */
 async function getTokens(ctx) {
    let num = await pool.then(function(conn) {
      return conn.query('select * from tokens');
    })
    ctx.body = num
  }


  /**
 * @api {get} /getToken
 * @apiGroup account
 * @apiVersion 1.0.0
 * @apiDescription 获取token 详情及 holder列表
 * @apiParam {String} contract
 * @apiParam {String} symbol
 */
 async function getToken(ctx) {
  let contract = ctx.request.query.contract
  let symbol = ctx.request.query.symbol
  let detail = await pool.then(function(conn) {
    return conn.query('select * from tokens where contract_ = ? and symbol = ?', [contract, symbol]);
  })
  let holders = await pool.then(function(conn) {
    return conn.query('select * from assets where contract_ = ? and symbol = ?', [contract, symbol]);
  })
  let result = {
    detail: detail,
    holders: holders
  }
  ctx.body = result
}


module.exports = {
    getAccountDetail: getAccountDetail,
    getNodeList: getNodeList,
    getAccountCount: getAccountCount,
    getTokens: getTokens,
    getToken: getToken
}
